# Conversion from Farenheit to Celsius
farenheit_to_celsius <- function(temp){
  celsius <- (temp - 32) * (5/9)
  return(celsius)
}