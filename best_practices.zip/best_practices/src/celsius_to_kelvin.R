celsius_to_kelvin <- function(temp){
  kelvin <- temp + 273.15
  return(kelvin)
}