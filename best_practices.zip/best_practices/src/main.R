# REPRODUCIBILITY AND BEST PRACTICES
# new comments are added.
# 2. Keep track of who wrote your code and its intended purpose
# The purpose of this code is to practice best practices
# author : us!
# date: 2020/07/28
#
# 1. Structure your project folder (CHECK!)

# 5. Keep code modular
# 6. Treat data as read-only *** Prevent confusion between original and
#    cleaned datasets
# 7. Treat output generated as disposable.
# 8. Test your code

# 3. Be explicit about the requirements and dependencies of your code
library(tidyverse)
library(ggplot2)
library(dplyr)

source("src/farenheit_to_celcius.R")
source("src/celsius_to_kelvin.R")

# 4. Limit the “hard-coding” of the input and output files for your script.
##############################
# USER INPUTS AND FILENAMES 
##############################
# inputs
input_data <- "data/temp_f.csv"
# outputs
#  data
output_data <- "munge/temp_f_c_k.csv"
#  graphs
hist_f <- "graphs/temp_f.png"
scatter_f_k <- 'graphs/temp_f_vs_k.png'


####### BEGIN PROGRAM ###########

# Read in data
temp_f <- read_csv(input_data)

# Convert to celsius
temps <- temp_f %>% mutate(temp_c = farenheit_to_celsius(temp_f))

# Convert to kelvin
temps <- temps %>% mutate(temp_k = celsius_to_kelvin(temp_c))


####  PLOTS
# plot histogram of temperature (F) data
ggplot(temps) + 
  geom_histogram(aes(x=temp_f)) + 
  xlab("Temperature (F)")
ggsave(hist_f, width=5, height=5)

# scatterplot of F vs K 
ggplot(temps, aes(temp_f,temp_k)) + 
  geom_point() +
  xlab("Temperature (F)") + 
  ylab("Temperature (K)")
ggsave(scatter_f_k, width=5, height=5)


# write results
write.csv(temps, file=output_data ,
          row.names=FALSE)

